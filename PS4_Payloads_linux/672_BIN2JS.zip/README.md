PS4 FW 6.72 Payload Converter by Storm21

PS4 FW 6.72 Payload Umwandler BIN2JS oder JS2BIN

- Download entpacken
- Der Payload "*.js" oder "*.bin" muss sich im selben Ordner befinden wie die Converter Dateien.
- Gewünschter Converter ausführen
- Payload Name eingeben oder einfügen mit Dateiendung ".js oder .bin", enter
- Der Payload wird umgewandelt und es entsteht jeweils der gewünschte Payload im .js oder .bin Format

